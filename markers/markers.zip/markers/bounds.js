//These are listed in alphabetical order
var alabamaBound = [
    [-88.525809,30.209612], // Southwest coordinates
    [-85.589960,35.008490]  // Northeast coordinates
];
